Followed tutorial: 

![Screen Shot](./image/image01.png)